let attendance = {};

const attendanceData = {};

function markAttendance(status, studentId) {
  const date = new Date().toLocaleDateString();
  attendanceData[date] = attendanceData[date] || {};
  attendanceData[date][studentId] = status;
  console.log(`Attendance marked for Student ${studentId}: ${status}`);
}

//function markAttendance(status, studentName) {
//if (status === 'present') {
//attendance[studentName] = true;
//} else if (status === 'absent') {
// attendance[studentName] = false;
// }
//}

function sendAbsentOnWhatsApp() {
  let absentNumbers = [];
  for (let studentName in attendance) {
    if (attendance[studentName] === false) {
      absentNumbers.push(studentName);
    }
  }
  let message = "Absent students: " + absentNumbers.join(", ");
  window.open("https://wa.me/?text=" + message);
}

function viewAttendanceData() {
  const dataDiv = document.getElementById('attendance-data');
  dataDiv.innerHTML = '';
  for (const [date, attendance] of Object.entries(attendanceData)) {
    const dateHeading = document.createElement('h2');
    dateHeading.innerText = date;
    dataDiv.appendChild(dateHeading);

    const table = document.createElement('table');
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    const nameHeader = document.createElement('th');
    nameHeader.innerText = 'Student Name';
    headerRow.appendChild(nameHeader);
    const statusHeader = document.createElement('th');
    statusHeader.innerText = 'Attendance';
    headerRow.appendChild(statusHeader);
    thead.appendChild(headerRow);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');
    for (const [studentId, status] of Object.entries(attendance)) {
      const row = document.createElement('tr');
      const nameCell = document.createElement('td');
      nameCell.innerText = ` ${studentId}`;
      row.appendChild(nameCell);
      const statusCell = document.createElement('td');
      statusCell.innerText = status;
      row.appendChild(statusCell);
      tbody.appendChild(row);
    }
    table.appendChild(tbody);
    dataDiv.appendChild(table);
  }
}
